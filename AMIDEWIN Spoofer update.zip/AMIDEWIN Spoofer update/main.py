import os
import random
import sys
import string
import time

# Function to generate random serials
def genSerials(length=16):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

# Function to generate random default strings
def genDefaultString(length=12):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

# Function to generate random OEM strings
def genOEMString():
    return "OEM-" + ''.join(random.choice(string.ascii_uppercase) for _ in range(4))

# Get a logo from https://patorjk.com/software/taag/
logo = """
  /$$$$$$  /$$        /$$$$$$  /$$     /$$ /$$$$$$$   /$$$$$$  /$$   /$$        /$$$$$$  /$$$$$$$   /$$$$$$   /$$$$$$  /$$$$$$$$ /$$$$$$$$ /$$$$$$$ 
 /$$__  $$| $$       /$$__  $$|  $$   /$$/| $$__  $$ /$$__  $$| $$  / $$       /$$__  $$| $$__  $$ /$$__  $$ /$$__  $$| $$_____/| $$_____/| $$__  $$
| $$  \__/| $$      | $$  \ $$ \  $$ /$$/ | $$  \ $$| $$  \ $$|  $$/ $$/      | $$  \__/| $$  \ $$| $$  \ $$| $$  \ $$| $$      | $$      | $$  \ $$
|  $$$$$$ | $$      | $$$$$$$$  \  $$$$/  | $$  | $$| $$  | $$ \  $$$$/       |  $$$$$$ | $$$$$$$/| $$  | $$| $$  | $$| $$$$$   | $$$$$   | $$$$$$$/
 \____  $$| $$      | $$__  $$   \  $$/   | $$  | $$| $$  | $$  >$$  $$        \____  $$| $$____/ | $$  | $$| $$  | $$| $$__/   | $$__/   | $$__  $$
 /$$  \ $$| $$      | $$  | $$    | $$    | $$  | $$| $$  | $$ /$$/\  $$       /$$  \ $$| $$      | $$  | $$| $$  | $$| $$      | $$      | $$  \ $$
|  $$$$$$/| $$$$$$$$| $$  | $$    | $$    | $$$$$$$/|  $$$$$$/| $$  \ $$      |  $$$$$$/| $$      |  $$$$$$/|  $$$$$$/| $$      | $$$$$$$$| $$  | $$
 \______/ |________/|__/  |__/    |__/    |_______/  \______/ |__/  |__/       \______/ |__/       \______/  \______/ |__/      |________/|__/  |__/
"""

# Function for cleaning operations
def run_cleaners():
    # Liste des fichiers de nettoyage
    cleaners = [
        "clean1.bat",
        "clean2.bat",
        "clean3.bat",
        "clean4.exe"
    ]

    # Exécution de chaque nettoyeur un par un
    for cleaner in cleaners:
        cleaner_path = os.path.join(r"C:\Users\lukaa\Desktop\spoof\Slaydox_perm_and_temp\cleaners", cleaner)  # Replace with the actual path to your cleaners
        if os.path.isfile(cleaner_path):  # Check if the file exists
            print(f"Running {cleaner}...")
            os.system(cleaner_path)
            time.sleep(1)  # Attendre une seconde entre les exécutions (optionnel)
        else:
            print(f"{cleaner} not found!")

# Basic choices
os.system("cls")
print(logo + "\n\n")
choice = input("[1] Perm Spoof\n[2] Temp Spoof\n[3] Run Cleaners\n[4] Asus Perm Spoof\n[5] Check your HWID\n[6] Exit\n\nEnter your choice: ")

if choice == "1":
    # General Perm Spoofing
    print("Executing General Perm Spoof...")
    os.system("AMIDEWINx64.EXE /IVN \"AMIDEWIN\"")
    os.system("AMIDEWINx64.EXE /SP \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /SV \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /SS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /SU AUTO")
    os.system("AMIDEWINx64.EXE /SK \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /BM \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /BS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /BT \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /BLC \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CM \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CV \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /CA \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CSK \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /PSN \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /PAT \"" + genOEMString() + "\"")

    # Ouvrir l'application HardDisk après le spoofing
    hard_disk_path = os.path.join(os.path.dirname(__file__), "HardDisk.exe")  # Chemin vers l'exécutable HardDisk
    if os.path.isfile(hard_disk_path):  # Vérifier si le fichier existe
        print("Opening HardDisk application...")
        os.startfile(hard_disk_path)  # Ouvrir l'application HardDisk
    else:
        print("HardDisk application not found!")

    # Ouvrir l'application CRU pour monitor spoof
    cru_path = r"C:\Users\lukaa\Desktop\spoof\Slaydox_perm_and_temp\monitor serial\CRU.exe"  # Chemin vers l'exécutable CRU
    if os.path.isfile(cru_path):  # Vérifier si le fichier existe
        print("Opening CRU application...")
        os.startfile(cru_path)  # Ouvrir l'application CRU
    else:
        print("CRU application not found!")

    print("General Perm Spoofing Complete! Exiting...")
    time.sleep(3)
    sys.exit()

elif choice == "2":
    # Temp Spoofing
    print("Temp Spoofing!")
    os.system("cd libs && kdmapper.exe driver.sys")
    print("Spoofing Complete! Exiting...")
    time.sleep(3)
    sys.exit()

elif choice == "3":
    # Running cleaners
    print("Running cleaners...")
    run_cleaners()
    print("Cleaners execution complete! Exiting...")
    time.sleep(3)
    sys.exit()

elif choice == "6":
    print("Exiting!")
    time.sleep(3)
    sys.exit()

elif choice == "4":
    # Asus Perm Spoofing
    print("Executing Asus Perm Spoof...")
    
    # Removing specific model requirement to apply to all ASUS
    os.system("AMIDEWINx64.EXE /IVN \"ASUS\"")
    os.system("AMIDEWINx64.EXE /SP \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /SV \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /SS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /SU AUTO")
    os.system("AMIDEWINx64.EXE /SK \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /BM \"ASUS\"")

    # Avoiding specific model by not using /BP
    os.system("AMIDEWINx64.EXE /BS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /BT \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /BLC \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CM \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CV \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CS \"" + genSerials() + "\"")
    os.system("AMIDEWINx64.EXE /CA \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /CSK \"" + genDefaultString() + "\"")
    os.system("AMIDEWINx64.EXE /PSN \"" + genOEMString() + "\"")
    os.system("AMIDEWINx64.EXE /PAT \"" + genOEMString() + "\"")

    print("Asus Perm Spoofing Complete! Exiting...")
    time.sleep(3)
    sys.exit()

elif choice == "5":
    print("Checking HWID!")
    os.system("cd libs && checker.bat")
    print("Exiting!")
    time.sleep(3)
    sys.exit()

else:
    print("Invalid choice! Exiting!")
    time.sleep(3)
    sys.exit()