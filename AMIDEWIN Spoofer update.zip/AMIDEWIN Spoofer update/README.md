# amidewin 💻
AMIDEWIN Spoofer made in python. Should work on most games besides valorant, but very detected.

# Roadmap 🗺️
✅ 0 Stars = Perm Spoofing

✅ 5 Stars = https://keyauth.cc/ Integration

✅ 10 Stars = Temp Spoofing + HWID Checker added

❌ 15 Stars = Cleaners + Mac spoofing + Monitor Spoofing (yes I will add this soon dw)

❌ 30 Stars = GUI Integration (customtkinter) + Asus Perm Spoofing

❌ 50 Stars = Locked (OEM) Perm Spoofing + Custom Mapper for Temp Spoofing

❌ 100 Stars = TPM Bypass (for valorant) + (Semi) Undetected Spoofing Methods 

# Showcase/tutorial video 📽️
https://www.youtube.com/watch?v=_8TVA-BzO9k&t=7s

# How to use 📗
Download the exe from releases or main.py, and put them in the same folder as everything else in the repo.
Run the exe/main.py, and select an option. Click yes on all prompts requesting admin.

# Compatabilty 🧭
Should work on all motherboards besides Asus or OEM motherboards (HP, Lenovo, Dell, Alienware)
